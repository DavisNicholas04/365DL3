package com.company.TFIDF;

public class Term {
    public String key;
    public int numberOfTimesWordUsed = 1;

    public Term(String key) {
        this.key = key;
    }
}