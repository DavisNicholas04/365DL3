package com.company;

import com.company.GUI.app;

public class Main {

    public static void main(String[] args) {
        new app();
    }
}
